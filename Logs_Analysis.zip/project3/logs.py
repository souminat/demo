#!/usr/bin/env python3

"""Importing psycopg2 module to connect to database"""
import psycopg2


def connectdb():


    """Returns the connection object"""
    return psycopg2.connect("dbname=news")


# Query - "Top 3 popular articles of all time"
query1 = "select title,views from articles_view limit 3"

# Query - "Most popular article authors of all time"
query2 = "select * from articles_author_view"

# Query - "Days in which more than 1% of requests lead to errors"
query3 = "select * from error_log_view where \"Percent Error\" > 1"

# to store results(headers & records) as a list
query_one = dict()
query_one['header'] = "\n1) The top 3 popular articles of all time are:\n"

query_two = dict()
query_two['header'] = "\n2) Most popular authors of all time are:\n"

query_three = dict()
query_three['header'] = "\n3) Days with more than 1% of error requests:\n"


# function for fetching query data


def fetch_query(query):
    
	
	"""This function extracts data based on query passed"""
        db = connectdb()
        c = db.cursor()
        c.execute(query)
        querydata = c.fetchall()
        db.close()
        return querydata

# function for printing query output


def show_query(record):


    """This function prints the data extracted"""
        if 'popular' in record['header']:
            print(record['header'])
            for result in record['records']:
                print('\t' + str(result[0]) + ' - ' + str(result[1]) + ' views')
        else:
            print(record['header'])
            for result in record['records']:
                print('\t' + str(result[0]) + ' - ' + str(result[1]) + ' %')


# get the query results from fetch_query
query_one['records'] = fetch_query(query1)
query_two['records'] = fetch_query(query2)
query_three['records'] = fetch_query(query3)

# display the query result with show_query
show_query(query_one)
show_query(query_two)
show_query(query_three)
