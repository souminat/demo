var myLocations = [
    {
        title: 'Capgemini Pvt. Ltd.',
        lat: 12.822775,
        lng:  80.221835,
        type: 'Company Office'
    },
	{	
		title: 'TCS, Siruseri',
        lat: 12.829532,
        lng:  80.217806,
        type: 'Company Office'
	},
	{
		title: 'AGS Cinemas',
        lat: 12.850892,
        lng:  80.225633,
        type: 'Shopping/Movie'
	},
	{
		title: 'OMR Food Street',
        lat: 12.848575 ,
        lng:  80.226355,
        type: 'Food'
	},
	{
		title: 'Radiance Ivy Terrace',
        lat: 12.837922,
        lng:  80.229380,
        type: 'Apartments'	
	}, 
	{
		title: 'Cognizant Office',
        lat: 12.825287,
        lng:  80.219734,
        type: 'Company Office'	
	},
	{
		title: 'HDFC Bank',
        lat: 12.833708,
        lng:  80.228896,
        type: 'Bank'
	}
]