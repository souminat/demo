#! /usr/bin/env python3

import psycopg2
DB_NAME = "news"

#Query for "What are the most popular three articles of all time?"
query1 = "select title,views from article_view limit 3"

#Query for "Who are the most popular article authors of all time?"
query2 = """select authors.name,sum(article_view.views) as views from
article_view,authors where authors.id = article_view.author
group by authors.name order by views desc"""

#Query for "On which days did more than 1% of requests lead to errors?"
query3 = "select * from error_log_view where \"Percent Error\" > 1"

#storing results of queries
query_1 = dict()
query_1['title'] = "\n1. The 3 most popular articles of all time are:\n"

query_2 = dict()
query_2['title'] = """\n2. The most popular article authors of
all time are:\n"""

query_3 = dict()
query_3['title'] = """\n3. Days with more than 1% of request that
lead to an error:\n"""


# function for fetching data using query
def get_query(query):
    db = psycopg2.connect(database=DB_NAME)
    c = db.cursor()
    c.execute(query)
    results = c.fetchall()
    db.close()
    return results

# function for printing query output
def print_query(query_result):
    print (query_result['title'])
    for result in query_result['results']:
        print ('\t' + str(result[0]) + ' ---> ' + str(result[1]) + ' views')

# function for printing third query
def print_error_query(query_result):
    print (query_result['title'])
    for result in query_result['results']:
        print ('\t' + str(result[0]) + ' ---> ' + str(result[1]) + ' %')


# stores query output in a variable
query_1['results'] = get_query(query1)
query_2['results'] = get_query(query2)
query_3['results'] = get_query(query3)

# prints output
print_query(query_1)
print_query(query_2)
print_error_query(query_3)
